const express = require('express');
const users = require('./users.json');
const fs = require('fs');
const bcrypt = require('bcrypt');
const { body, validationResult, check } = require('express-validator/check');
const { sanitizeBody } = require('express-validator/filter');
const auth = require('./middleware/auth')
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser')
const app = express();
app.use(cookieParser());

app.set('view engine', 'pug');

app.use(express.static(__dirname + '/public'));
app.use(express.urlencoded());

//index - login form
app.get('/',(req, res) => {
    res.render('index', {
        title: 'Login'
    });
});

//XSS - Secure
app.get('/secure', (req,res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    fs.readFile('./html/secure.html', null, function (error, data) {
        if (error) {
            res.writeHead(404);
            res.write('Whoops! File not found!');
        } else {
            res.write(data);
        }
        res.end();
    });
})
//String("//")
//XSS - Secure Message
app.get('/secure/message', [
    check('firstname', 'firstname is missing').isLength({ min: 1 }).trim().escape(),
    check('lastname', 'lastname is missing').isLength({ min: 1 }).trim().escape(),
], (req, res) => {
    var firstname = req.query.firstname;
    var lastname = req.query.lastname;
    const errors = validationResult(req);

    if(!errors.isEmpty()) {
        res.send('input missing for either firstname, lastname or both')
    } else {
        res.send(firstname + ' ' + lastname)
    }    
})

//XSS - Flaw
app.get('/flaw', (req,res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    fs.readFile('./html/flaw.html', null, function (error, data) {
        if (error) {
            res.writeHead(404);
            res.write('Whoops! File not found!');
        } else {
            res.write(data);
        }
        res.end();
    });
})

//XSS - Flaw Message
app.get('/flaw/message', (req, res) => {
    var firstname = req.query.firstname;
    var lastname = req.query.lastname;
    res.send(firstname + ' ' + lastname)
})

//Profile
app.get('/profile', (req, res) => {
    var userName = req.query.uname;
    var userPass = req.query.psw;
    if(userName && userPass) {
        const user = users.users.find(u => u.username == userName)
        if(user) {
            if(bcrypt.compareSync(userPass, user.password)) {
                const token = jwt.sign('myprivatekey', 'myprivatekey'); 
                res.cookie('cookieAuthKey', token, { expires: 0}) //expires after session is over
                res.render('profile', {
                    title:`Logged in as: ${userName}`
                })
            } else {
                res.render('index', {
                    title: 'Login', 
                    uName: userName,
                    errorMessage: 'Username or password is invalid, please try again!'
                })
            }
        } else {
            res.render('index', {
                title: 'Login', 
                uName: userName,
                errorMessage: 'Username or password is invalid, please try again!'
            })
        }
    } else {
        res.render('index', {
            title: 'Login', 
            uName: userName,
            errorMessage: 'Please provide an existing username with a password'
        })
    }    
})

//Registration Call
app.get('/registration', auth, (req, res) => {
    res.render('registration', {
        title: "Registration"
    });
});

//Registration Create User
app.post('/registration', [
    body('uname', 'Username missing').isLength({ min: 1 }).trim(),
    sanitizeBody('uname').escape(),
    body('email', 'Email missing').isLength({ min: 1 }),
    check('email', 'Invalid Email format').isEmail(),
    sanitizeBody('email').escape(),
    body('psw', 'Password missing').isLength({ min: 1}),
    body('psw', 'The password must contain 10 signs or more').isLength({ min: 10}),
    sanitizeBody('psw').escape(),
    body('confirmPsw', 'Re-enter password please').isLength({ min: 1}),
    body('confirmPsw', 'Password confirmation does not match password').custom((value, { req }) => {
        if(value !== req.body.psw) {
            throw new Error('Password confirmation does not match password')
        }
        return true;
    }),
    sanitizeBody('confirmPsw').escape(),
], (req, res) => {
    var username = req.body.uname;
    var email = req.body.email;
    var gender = req.body.gender;
    var password = req.body.psw;

    const errors = validationResult(req);

    if(!errors.isEmpty()) {
        res.render('registration', {
            title: 'Registration', 
            errors: errors.array(),
            uName: username,
            eMail: email,
            psW: password
        })
    } else {
        const checkUser = users.users.find(u => u.username == username);

        if(checkUser) {
            res.render('registration', {
                title: 'Registration', 
                errorMessage: 'User already exists',
                uName: username,
                eMail: email,
                psW: password
            })
        }

        let user = { username: username, email: email, gender: gender, password: bcrypt.hashSync(password, 10)};

        fs.readFile('./users.json', function (err, data) {
            var json = JSON.parse(data)
            json.users.push(user)
            fs.writeFile('./users.json', JSON.stringify(json), function(err))
        })
        res.render('registration', {
            title: 'Registration', 
            successMessage: 'User was successfully created!'
        })
    }    
});

//Helper Route - Hash Password for manual registration
app.get('/encrypt', (req, res) => {
    res.send('Password: ' + req.query.psw + ', encrypted: ' + bcrypt.hashSync(req.query.psw, 10))
})


const server = app.listen(7000, () => {
    console.log(`Express running PORT ${server.address().port}`);
});

