const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser')

const express = require('express');

const app = express();
app.use(cookieParser());

module.exports = function(req, res, next) {
  //get the token from the header if present
  const token = req.cookies.cookieAuthKey;

  //if no token found, return response (without going to the next middelware)
  if (!token) {
    console.log("No token found");
    return res.status(401).send("Access denied. No token provided.");
  } 

  try {
    //verify the token, pass to next middleware
    console.log('Header has token');
    const decoded = jwt.verify(token, 'myprivatekey');
    if(decoded) {
      next();
    } else {
      res.redirect('index')
    }
  } catch (ex) {
    //if invalid token
    console.log("invalid token");
    res.status(400).send("Invalid token.");
  }
};